...As Was Foretold
===============

Entry in PyWeek #16  <http://www.pyweek.org/16/>
URL: http://pyweek.org/e/Console
Team: Rectifier & BurritoAlPastor
Members: Jesse Truscott & Joe Gracyk
License: BSD


Running the Game
----------------

On Windows or Mac OS X, locate the "run_game.pyw" file and double-click it.

Otherwise open a terminal / console and "cd" to the game directory and run:

  python run_game.py

If you're using a system that doesn't support MP3 music, or just don't want
sounds, run "python run_game.py --no-sound" instead.


How to Play the Game
--------------------

Upload files to PyWeek with::

   python pyweek_upload.py
