import Console.main
if __name__ == "__main__":
    Console.main.main()
